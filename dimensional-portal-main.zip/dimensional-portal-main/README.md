# Dimensional Portal

Now upgrade the website's visual quality dramatically. Focus on making the central dimensional portal a genuine interactive Three.js object with orbital geometry, particle systems, cinematic lighting, and smooth mouse-reactive camera movement. Improve the scroll transitions so the user feels physically transported through different dimensions. Remove generic UI cards and unnecessary gradients. Make the typography more premium, the composition more cinematic, and the experience more mysterious. Test every button, fix all console errors, and ensure the website remains responsive and performant. Do not replace existing working features unnecessarily.

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/bf7efc6a-0d0a-4bb2-b5c6-56c7dee7c672).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
