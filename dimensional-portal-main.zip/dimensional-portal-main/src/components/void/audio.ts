export type Drone = { start: () => void; stop: () => void };

/** Synthesised cosmic drone — created only after a user gesture. */
export function createDrone(): Drone {
  let ctx: AudioContext | null = null;
  let master: GainNode | null = null;
  return {
    start() {
      if (!ctx) {
        ctx = new AudioContext();
        master = ctx.createGain();
        master.gain.value = 0;
        const filter = ctx.createBiquadFilter();
        filter.type = "lowpass";
        filter.frequency.value = 420;
        const delay = ctx.createDelay(2);
        delay.delayTime.value = 0.9;
        const fb = ctx.createGain();
        fb.gain.value = 0.45;
        delay.connect(fb).connect(delay);
        filter.connect(master);
        filter.connect(delay).connect(master);
        master.connect(ctx.destination);
        [55, 82.4, 110.3, 164.8].forEach((f, i) => {
          const o = ctx!.createOscillator();
          o.type = i % 2 ? "sine" : "triangle";
          o.frequency.value = f;
          o.detune.value = (i - 1.5) * 6;
          const g = ctx!.createGain();
          g.gain.value = 0.12 / (i + 1);
          const lfo = ctx!.createOscillator();
          lfo.frequency.value = 0.05 + i * 0.03;
          const lg = ctx!.createGain();
          lg.gain.value = 0.05 / (i + 1);
          lfo.connect(lg).connect(g.gain);
          o.connect(g).connect(filter);
          o.start(); lfo.start();
        });
      }
      void ctx.resume();
      master!.gain.cancelScheduledValues(ctx.currentTime);
      master!.gain.linearRampToValueAtTime(0.5, ctx.currentTime + 2.5);
    },
    stop() {
      if (!ctx || !master) return;
      master.gain.cancelScheduledValues(ctx.currentTime);
      master.gain.linearRampToValueAtTime(0, ctx.currentTime + 1);
      setTimeout(() => void ctx?.suspend(), 1100);
    },
  };
}
