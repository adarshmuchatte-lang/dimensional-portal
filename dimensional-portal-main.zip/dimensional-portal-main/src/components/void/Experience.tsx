import { Canvas } from "@react-three/fiber";
import { ArrowUpRight, Volume2, VolumeX } from "lucide-react";
import { useCallback, useEffect, useRef, useState, type ReactNode } from "react";
import { VoidScene } from "./Scene";
import { voidState } from "./state";
import { createDrone, type Drone } from "./audio";

const CHAPTERS = [
  { id: "threshold", n: "01", title: "The Threshold", body: "The gateway notices you. Light bends, matter accelerates, and the distance between here and elsewhere collapses to a single breath." },
  { id: "fractured", n: "02", title: "Fractured Reality", body: "Glass that remembers being stone. Planets split along lines no physics drew. Every surface reflects a version of you that never left." },
  { id: "abyss", n: "03", title: "The Cosmic Abyss", body: "An anomaly the size of a thousand suns, wearing a crown of debris. Here, isolation has a gravity of its own." },
  { id: "beyond", n: "04", title: "Beyond Existence", body: "Space folds into itself. Structure forgets its shape. What remains is not darkness — only the absence of an edge." },
];

function scrollToId(id: string) {
  document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
}

function Magnetic({ children, onClick, variant = "solid", label }: { children: ReactNode; onClick: () => void; variant?: "solid" | "ghost"; label?: string }) {
  const ref = useRef<HTMLButtonElement>(null);
  const move = (e: React.PointerEvent) => {
    const el = ref.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    el.style.transform = `translate(${(e.clientX - r.left - r.width / 2) * 0.25}px, ${(e.clientY - r.top - r.height / 2) * 0.35}px)`;
  };
  const leave = () => ref.current && (ref.current.style.transform = "");
  const base = "group relative inline-flex items-center gap-3 px-7 py-4 label-mono transition-[transform,background-color,color,box-shadow] duration-300 ease-out";
  const v = variant === "solid"
    ? "bg-foreground text-background hover:bg-ultraviolet hover:text-foreground hover:shadow-[0_0_40px_-6px_var(--ultraviolet)]"
    : "border border-border text-foreground hover:border-ultraviolet hover:text-foreground hover:shadow-[0_0_30px_-10px_var(--ultraviolet)]";
  return (
    <button ref={ref} type="button" aria-label={label} data-cursor="hover" onPointerMove={move} onPointerLeave={leave} onClick={onClick} className={`${base} ${v}`}>
      {children}
    </button>
  );
}

function Loader({ done }: { done: boolean }) {
  const [p, setP] = useState(0);
  useEffect(() => {
    const id = setInterval(() => setP((v) => Math.min(v + Math.random() * 14, done ? 100 : 92)), 120);
    return () => clearInterval(id);
  }, [done]);
  const hidden = done && p >= 100;
  return (
    <div className={`fixed inset-0 z-[60] flex flex-col items-center justify-center bg-background transition-opacity duration-1000 ${hidden ? "pointer-events-none opacity-0" : "opacity-100"}`}>
      <p className="label-mono text-muted-foreground"><span className="animate-flicker">INITIALIZING THE VOID...</span></p>
      <div className="mt-6 h-px w-56 bg-border">
        <div className="h-px bg-foreground transition-[width] duration-200" style={{ width: `${p}%` }} />
      </div>
      <p className="label-mono mt-4 text-ultraviolet">{String(Math.floor(p)).padStart(3, "0")}</p>
    </div>
  );
}

function Cursor() {
  const dot = useRef<HTMLDivElement>(null);
  const ring = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!window.matchMedia("(pointer: fine)").matches) return;
    document.body.classList.add("void-cursor");
    let x = innerWidth / 2, y = innerHeight / 2, rx = x, ry = y, raf = 0, big = false;
    const mv = (e: PointerEvent) => {
      x = e.clientX; y = e.clientY;
      big = !!(e.target as HTMLElement).closest?.("[data-cursor=hover],a,button");
    };
    const loop = () => {
      rx += (x - rx) * 0.15; ry += (y - ry) * 0.15;
      if (dot.current) dot.current.style.transform = `translate(${x}px,${y}px)`;
      if (ring.current) ring.current.style.transform = `translate(${rx}px,${ry}px) scale(${big ? 1.8 : 1})`;
      raf = requestAnimationFrame(loop);
    };
    addEventListener("pointermove", mv);
    loop();
    return () => { removeEventListener("pointermove", mv); cancelAnimationFrame(raf); document.body.classList.remove("void-cursor"); };
  }, []);
  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 z-[70] hidden [@media(pointer:fine)]:block">
      <div ref={dot} className="absolute -left-1 -top-1 size-2 rounded-full bg-foreground shadow-[0_0_12px_2px_var(--ultraviolet)]" />
      <div ref={ring} className="absolute -left-5 -top-5 size-10 rounded-full border border-foreground/40 transition-[scale] duration-300" />
    </div>
  );
}

export function Experience() {
  const [ready, setReady] = useState(false);
  const [low, setLow] = useState(false);
  const [sound, setSound] = useState(false);
  const [chapter, setChapter] = useState(-1);
  const [end, setEnd] = useState(0);
  const drone = useRef<Drone | null>(null);
  const heroRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setLow(innerWidth < 768 || (navigator.hardwareConcurrency ?? 8) <= 4 || matchMedia("(prefers-reduced-motion: reduce)").matches);
    const onScroll = () => {
      const max = document.documentElement.scrollHeight - innerHeight;
      const p = max > 0 ? scrollY / max : 0;
      voidState.scroll = p;
      setChapter(p < 0.12 ? -1 : Math.min(3, Math.floor((p - 0.12) / 0.22)));
      setEnd(Math.max(0, (p - 0.9) / 0.1));
      if (heroRef.current) {
        const h = Math.min(scrollY / innerHeight, 1);
        heroRef.current.style.opacity = String(1 - h * 1.4);
        heroRef.current.style.transform = `translateY(${h * -80}px) scale(${1 + h * 0.15})`;
        heroRef.current.style.filter = `blur(${h * 8}px)`;
      }
    };
    const onMove = (e: PointerEvent) => {
      voidState.mouseX = (e.clientX / innerWidth) * 2 - 1;
      voidState.mouseY = -((e.clientY / innerHeight) * 2 - 1);
      const dx = e.clientX - innerWidth / 2, dy = e.clientY - innerHeight / 2;
      const near = 1 - Math.min(Math.hypot(dx, dy) / (Math.min(innerWidth, innerHeight) * 0.45), 1);
      voidState.hover = voidState.scroll < 0.15 ? near * near : 0;
    };
    onScroll();
    addEventListener("scroll", onScroll, { passive: true });
    addEventListener("pointermove", onMove, { passive: true });
    return () => { removeEventListener("scroll", onScroll); removeEventListener("pointermove", onMove); drone.current?.stop(); };
  }, []);

  const toggleSound = useCallback(() => {
    if (!drone.current) drone.current = createDrone();
    if (sound) drone.current.stop(); else drone.current.start();
    setSound(!sound);
  }, [sound]);

  const enter = () => {
    voidState.enter = 1;
    setTimeout(() => scrollToId("threshold"), 450);
  };

  return (
    <>
      <Loader done={ready} />
      <Cursor />

      <div className="fixed inset-0 z-0" aria-hidden>
        <Canvas
          dpr={low ? [1, 1.25] : [1, 1.75]}
          camera={{ position: [0, 0.6, 16], fov: 55, near: 0.1, far: 400 }}
          gl={{ antialias: !low, powerPreference: "high-performance" }}
          onCreated={() => setTimeout(() => setReady(true), 400)}
        >
          <VoidScene low={low} />
        </Canvas>
      </div>
      <div aria-hidden className="pointer-events-none fixed inset-0 z-[1] vignette" />
      <div aria-hidden className="pointer-events-none fixed inset-0 z-[1] grain opacity-[0.06] mix-blend-overlay" />
      <div aria-hidden className="pointer-events-none fixed inset-0 z-[5] bg-background" style={{ opacity: end }} />

      {/* Nav */}
      <header className="fixed inset-x-0 top-0 z-40 flex items-center justify-between px-6 py-6 md:px-12">
        <button type="button" data-cursor="hover" onClick={() => scrollTo({ top: 0, behavior: "smooth" })} className="font-display text-lg font-bold tracking-[0.2em]">
          VOID<sup className="text-ultraviolet">®</sup>
        </button>
        <button type="button" data-cursor="hover" onClick={() => scrollToId("threshold")} className="label-mono flex items-center gap-2 text-foreground/80 transition-colors hover:text-foreground">
          <span className="hidden sm:inline">Explore the unknown</span><span className="sm:hidden">Explore</span> <ArrowUpRight className="size-3.5" />
        </button>
      </header>

      {/* Chapter rail */}
      <nav aria-label="Chapters" className="fixed right-6 top-1/2 z-40 hidden -translate-y-1/2 flex-col gap-4 md:flex">
        {CHAPTERS.map((c, i) => (
          <button key={c.id} type="button" data-cursor="hover" onClick={() => scrollToId(c.id)} aria-label={`Go to chapter ${c.n}: ${c.title}`} className="group flex items-center justify-end gap-3">
            <span className={`label-mono transition-opacity ${chapter === i ? "opacity-100" : "opacity-0 group-hover:opacity-60"}`}>{c.n}</span>
            <span className={`block h-px transition-all duration-500 ${chapter === i ? "w-10 bg-ultraviolet" : "w-4 bg-foreground/40"}`} />
          </button>
        ))}
      </nav>

      <button type="button" data-cursor="hover" onClick={toggleSound} aria-label={sound ? "Mute ambient sound" : "Play ambient sound"} className="label-mono fixed bottom-6 left-6 z-40 flex items-center gap-2 text-muted-foreground transition-colors hover:text-foreground md:left-12">
        {sound ? <Volume2 className="size-4" /> : <VolumeX className="size-4" />} <span>{sound ? "Sound on" : "Sound off"}</span>
      </button>

      <main className="relative z-10">
        {/* Hero */}
        <section className="relative flex h-svh items-center justify-center px-6">
          <div ref={heroRef} className="flex flex-col items-center text-center will-change-transform">
            <p className="label-mono mb-6 text-ultraviolet">Transmission 000 — Origin unknown</p>
            <h1 className="font-display text-[21vw] font-extrabold leading-[0.8] tracking-[-0.04em] md:text-[15rem]">VOID</h1>
            <p className="mt-4 font-serif text-3xl italic tracking-wide md:text-5xl">Into the unknown.</p>
            <p className="mt-6 max-w-md text-sm leading-relaxed text-muted-foreground md:text-base">
              Somewhere beyond the edge of reality, another universe is waiting.
            </p>
            <div className="mt-10 flex flex-col gap-4 sm:flex-row">
              <Magnetic onClick={enter}>Enter the void</Magnetic>
              <Magnetic variant="ghost" onClick={() => scrollToId("fractured")}>Discover the dimensions</Magnetic>
            </div>
          </div>
          <button type="button" data-cursor="hover" onClick={() => scrollToId("threshold")} className="absolute bottom-8 left-1/2 flex -translate-x-1/2 flex-col items-center gap-3 text-muted-foreground">
            <span className="label-mono hidden sm:block">Descend into the unknown</span>
            <span className="relative block h-12 w-px overflow-hidden bg-border"><span className="animate-descend absolute inset-x-0 top-0 h-1/2 bg-foreground" /></span>
          </button>
        </section>

        {CHAPTERS.map((c, i) => (
          <section key={c.id} id={c.id} className={`flex min-h-[160svh] items-center px-6 md:px-24 ${i % 2 ? "justify-end text-right" : "justify-start"}`}>
            <div className={`max-w-xl transition-all duration-[1400ms] ease-out ${chapter === i ? "translate-y-0 opacity-100 blur-0" : "translate-y-12 opacity-0 blur-sm"}`}>
              <p className="label-mono text-ultraviolet">Chapter {c.n}</p>
              <h2 className="mt-5 font-display text-5xl font-bold uppercase leading-[0.9] tracking-[-0.02em] md:text-7xl lg:text-8xl">{c.title}</h2>
              <p className={`mt-8 max-w-sm font-serif text-xl italic leading-snug text-muted-foreground md:text-2xl ${i % 2 ? "ml-auto" : ""}`}>{c.body}</p>
            </div>
          </section>
        ))}

        <section id="end" className="relative z-10 flex h-svh flex-col items-center justify-center px-6 text-center">
          <p className="label-mono text-muted-foreground" style={{ opacity: end }}>End of transmission</p>
          <h2 className="mt-6 max-w-4xl font-display text-3xl font-bold uppercase leading-[1.05] tracking-[-0.01em] md:text-6xl" style={{ opacity: end }}>
            The universe ends where <span className="font-serif font-normal normal-case italic text-ultraviolet">your imagination</span> begins.
          </h2>
          <div className="mt-12" style={{ opacity: end }}>
            <Magnetic variant="ghost" onClick={() => scrollTo({ top: 0, behavior: "smooth" })}>Return to reality <ArrowUpRight className="size-3.5" /></Magnetic>
          </div>
        </section>
      </main>
    </>
  );
}
