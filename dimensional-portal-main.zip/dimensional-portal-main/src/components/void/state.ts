// Shared mutable state between the DOM overlay and the 3D scene (no re-renders).
export const voidState = {
  scroll: 0, // 0..1 target page progress
  smooth: 0, // eased progress used by the scene
  mouseX: 0, // -1..1
  mouseY: 0,
  hover: 0, // portal proximity glow 0..1
  enter: 0, // click "enter" impulse 0..1
};

/** Camera z keyframes per chapter: hero, threshold, fractured, abyss, beyond. */
export const CAMERA_Z = [16, 5, -46, -104, -170];

export function cameraZAt(p: number) {
  const seg = CAMERA_Z.length - 1;
  const x = Math.min(Math.max(p, 0), 1) * seg;
  const i = Math.min(Math.floor(x), seg - 1);
  const t = x - i;
  const e = t * t * (3 - 2 * t);
  const a = CAMERA_Z[i]!, b = CAMERA_Z[i + 1]!;
  return a + (b - a) * e;
}
