import { useFrame, useThree } from "@react-three/fiber";
import { useMemo, useRef } from "react";
import * as THREE from "three";
import { cameraZAt, voidState } from "./state";

const VIOLET = new THREE.Color("#7C3AED");
const BLUE = new THREE.Color("#38BDF8");
const MAGENTA = new THREE.Color("#D946EF");
const WHITE = new THREE.Color("#F5F3FF");

function rng(seed: number) {
  let s = seed;
  return () => {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
}

/* ---------------- Stars ---------------- */
function Stars({ count }: { count: number }) {
  const geo = useMemo(() => {
    const r = rng(7);
    const pos = new Float32Array(count * 3);
    const col = new Float32Array(count * 3);
    const c = new THREE.Color();
    for (let i = 0; i < count; i++) {
      pos[i * 3] = (r() - 0.5) * 260;
      pos[i * 3 + 1] = (r() - 0.5) * 160;
      pos[i * 3 + 2] = 40 - r() * 260;
      c.copy(WHITE).lerp(r() > 0.5 ? BLUE : VIOLET, r() * 0.6);
      col.set([c.r, c.g, c.b], i * 3);
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.BufferAttribute(pos, 3));
    g.setAttribute("color", new THREE.BufferAttribute(col, 3));
    return g;
  }, [count]);
  return (
    <points geometry={geo}>
      <pointsMaterial size={0.18} vertexColors transparent opacity={0.85} sizeAttenuation depthWrite={false} blending={THREE.AdditiveBlending} />
    </points>
  );
}

/* ---------------- Portal core (shader disk) ---------------- */
const portalVert = /* glsl */ `
varying vec2 vUv;
void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }`;
const portalFrag = /* glsl */ `
uniform float uTime; uniform float uHover; uniform vec3 uA; uniform vec3 uB; uniform vec3 uC;
varying vec2 vUv;
float hash(vec2 p){ return fract(sin(dot(p, vec2(127.1,311.7)))*43758.5453); }
float noise(vec2 p){ vec2 i=floor(p); vec2 f=fract(p); f=f*f*(3.-2.*f);
  return mix(mix(hash(i),hash(i+vec2(1,0)),f.x),mix(hash(i+vec2(0,1)),hash(i+vec2(1,1)),f.x),f.y); }
float fbm(vec2 p){ float v=0.; float a=.5; for(int i=0;i<5;i++){ v+=a*noise(p); p*=2.03; a*=.5;} return v; }
void main(){
  vec2 p = vUv*2.-1.;
  float r = length(p);
  float a = atan(p.y,p.x);
  // swirl coordinates — angular velocity grows near the horizon
  float sw = a + uTime*0.25 + 2.2/(r+0.15);
  vec2 q = vec2(cos(sw), sin(sw))*r*3.0;
  float n = fbm(q + vec2(uTime*0.05, 0.));
  float horizon = 0.28;
  float ring = smoothstep(horizon-0.02, horizon+0.01, r) * exp(-(r-horizon)*5.0);
  float disk = smoothstep(horizon, horizon+0.05, r) * smoothstep(1.0, 0.35, r) * n;
  float photon = exp(-pow((r-horizon-0.015)*60.0, 2.0));
  vec3 col = mix(uA, uB, n) * disk * 1.4 + mix(uC, vec3(1.), .4) * photon * (1.2 + uHover*1.5);
  col += uA * ring * (0.6 + uHover);
  float core = smoothstep(horizon+0.005, horizon-0.03, r);
  float alpha = clamp(max(max(disk, photon), ring) * (0.9+uHover*0.4), 0., 1.);
  alpha = mix(alpha, 1.0, core);
  col *= (1.0-core);
  gl_FragColor = vec4(col, alpha * smoothstep(1.0, 0.8, r));
}`;

function PortalCore() {
  const mat = useRef<THREE.ShaderMaterial>(null);
  const halo = useRef<THREE.Mesh>(null);
  const uniforms = useMemo(
    () => ({ uTime: { value: 0 }, uHover: { value: 0 }, uA: { value: VIOLET }, uB: { value: MAGENTA }, uC: { value: BLUE } }),
    [],
  );
  useFrame(({ camera }, d) => {
    if (!mat.current) return;
    mat.current.uniforms['uTime']!.value += d;
    mat.current.uniforms['uHover']!.value = THREE.MathUtils.damp(mat.current.uniforms['uHover']!.value, voidState.hover + voidState.enter, 4, d);
    if (halo.current) halo.current.quaternion.copy(camera.quaternion);
  });
  return (
    <group>
      <mesh ref={halo} renderOrder={2}>
        <planeGeometry args={[14, 14]} />
        <shaderMaterial ref={mat} uniforms={uniforms} vertexShader={portalVert} fragmentShader={portalFrag} transparent depthWrite={false} />
      </mesh>
    </group>
  );
}

/* ---------------- Orbital rings ---------------- */
function Rings() {
  const refs = useRef<(THREE.Group | null)[]>([]);
  const rings = useMemo(
    () => [
      { r: 3.6, tube: 0.012, tilt: [1.2, 0.2, 0], speed: 0.22, color: VIOLET, op: 0.9 },
      { r: 4.4, tube: 0.008, tilt: [1.45, -0.35, 0.3], speed: -0.14, color: BLUE, op: 0.7 },
      { r: 5.3, tube: 0.006, tilt: [0.9, 0.5, -0.2], speed: 0.09, color: MAGENTA, op: 0.55 },
      { r: 6.4, tube: 0.004, tilt: [1.6, 0.1, 0.8], speed: -0.06, color: WHITE, op: 0.35 },
      { r: 7.8, tube: 0.003, tilt: [1.1, -0.8, 0.1], speed: 0.04, color: VIOLET, op: 0.3 },
    ],
    [],
  );
  useFrame((_, d) => {
    refs.current.forEach((g, i) => {
      if (g) g.rotation.z += rings[i]!.speed * d * (1 + voidState.enter * 4);
    });
  });
  return (
    <>
      {rings.map((r, i) => (
        <group key={i} rotation={r.tilt as [number, number, number]}>
          <group ref={(el) => (refs.current[i] = el)}>
            <mesh>
              <torusGeometry args={[r.r, r.tube, 6, 220]} />
              <meshBasicMaterial color={r.color} transparent opacity={r.op} blending={THREE.AdditiveBlending} depthWrite={false} />
            </mesh>
            {/* energy node travelling along ring */}
            <mesh position={[r.r, 0, 0]}>
              <sphereGeometry args={[0.05 + r.tube * 4, 10, 10]} />
              <meshBasicMaterial color={WHITE} />
            </mesh>
          </group>
        </group>
      ))}
    </>
  );
}

/* ---------------- Particles attracted into the portal ---------------- */
const inflowVert = /* glsl */ `
attribute float aSeed; attribute float aR; attribute float aA;
uniform float uTime; uniform float uSpeed; uniform float uPix;
varying float vFade; varying float vSeed;
void main(){
  float life = fract(aSeed + uTime*0.04*uSpeed);
  float r = mix(aR, 0.9, life*life);
  float ang = aA + uTime*0.2 + 3.0/(r+0.2)*life;
  float y = (aSeed-0.5) * 2.0 * r * 0.18;
  vec3 p = vec3(cos(ang)*r, y, sin(ang)*r);
  vec4 mv = modelViewMatrix * vec4(p,1.0);
  gl_Position = projectionMatrix * mv;
  vFade = smoothstep(0.0,0.15,life) * smoothstep(1.0,0.8,life);
  vSeed = aSeed;
  gl_PointSize = uPix * (0.6 + aSeed) * (12.0 / -mv.z);
}`;
const inflowFrag = /* glsl */ `
uniform vec3 uA; uniform vec3 uB; varying float vFade; varying float vSeed;
void main(){ float d = length(gl_PointCoord-0.5); float a = smoothstep(0.5,0.0,d);
  gl_FragColor = vec4(mix(uA,uB,vSeed), a*vFade); }`;

function Inflow({ count }: { count: number }) {
  const mat = useRef<THREE.ShaderMaterial>(null);
  const { gl } = useThree();
  const geo = useMemo(() => {
    const r = rng(42);
    const seed = new Float32Array(count), rad = new Float32Array(count), ang = new Float32Array(count);
    for (let i = 0; i < count; i++) {
      seed[i] = r();
      rad[i] = 4 + r() * 14;
      ang[i] = r() * Math.PI * 2;
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.BufferAttribute(new Float32Array(count * 3), 3));
    g.setAttribute("aSeed", new THREE.BufferAttribute(seed, 1));
    g.setAttribute("aR", new THREE.BufferAttribute(rad, 1));
    g.setAttribute("aA", new THREE.BufferAttribute(ang, 1));
    g.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 30);
    return g;
  }, [count]);
  const uniforms = useMemo(
    () => ({ uTime: { value: 0 }, uSpeed: { value: 1 }, uPix: { value: gl.getPixelRatio() * 1.6 }, uA: { value: BLUE }, uB: { value: MAGENTA } }),
    [gl],
  );
  useFrame((_, d) => {
    if (!mat.current) return;
    const p = voidState.smooth;
    const target = 1 + Math.min(p * 4, 1) * 5 + voidState.enter * 8;
    mat.current.uniforms['uSpeed']!.value = THREE.MathUtils.damp(mat.current.uniforms['uSpeed']!.value, target, 2, d);
    mat.current.uniforms['uTime']!.value += d * mat.current.uniforms['uSpeed']!.value * 0.5 + d * 0.5;
  });
  return (
    <points geometry={geo} rotation={[0.35, 0, 0.1]}>
      <shaderMaterial ref={mat} uniforms={uniforms} vertexShader={inflowVert} fragmentShader={inflowFrag} transparent depthWrite={false} blending={THREE.AdditiveBlending} />
    </points>
  );
}

/* ---------------- Monoliths (instanced) ---------------- */
function Monoliths({ count, z, spread, seed, glass }: { count: number; z: number; spread: number; seed: number; glass?: boolean }) {
  const ref = useRef<THREE.InstancedMesh>(null);
  const data = useMemo(() => {
    const r = rng(seed);
    return Array.from({ length: count }, () => ({
      p: new THREE.Vector3((r() - 0.5) * spread, (r() - 0.5) * spread * 0.55, z + (r() - 0.5) * spread * 0.8),
      s: new THREE.Vector3(0.3 + r() * 0.8, 1 + r() * 3.5, 0.15 + r() * 0.4).multiplyScalar(glass ? 1.3 : 1),
      rot: new THREE.Euler(r() * 3, r() * 3, r() * 3),
      spin: (r() - 0.5) * 0.3,
      drift: (r() - 0.5) * 0.6,
    }));
  }, [count, z, spread, seed, glass]);
  const dummy = useMemo(() => new THREE.Object3D(), []);
  useFrame(({ clock }) => {
    const m = ref.current;
    if (!m) return;
    const t = clock.elapsedTime;
    const sc = voidState.smooth;
    data.forEach((o, i) => {
      dummy.position.set(o.p.x + Math.sin(t * 0.2 + i) * o.drift + o.drift * sc * 20, o.p.y + Math.cos(t * 0.15 + i) * 0.4, o.p.z);
      dummy.rotation.set(o.rot.x + t * o.spin, o.rot.y + t * o.spin * 0.7 + sc * o.drift * 6, o.rot.z);
      dummy.scale.copy(o.s);
      dummy.updateMatrix();
      m.setMatrixAt(i, dummy.matrix);
    });
    m.instanceMatrix.needsUpdate = true;
  });
  return (
    <instancedMesh ref={ref} args={[undefined, undefined, count]} castShadow>
      <boxGeometry args={[1, 1, 1]} />
      {glass ? (
        <meshPhysicalMaterial color="#1a0b33" roughness={0.08} metalness={0.2} transmission={0} transparent opacity={0.55} clearcoat={1} emissive={VIOLET} emissiveIntensity={0.08} />
      ) : (
        <meshStandardMaterial color="#0d0a14" roughness={0.35} metalness={0.85} />
      )}
    </instancedMesh>
  );
}

/* ---------------- Dimensional cracks ---------------- */
function Cracks({ z }: { z: number }) {
  const geo = useMemo(() => {
    const r = rng(99);
    const pts: number[] = [];
    for (let k = 0; k < 14; k++) {
      let x = (r() - 0.5) * 40, y = (r() - 0.5) * 20;
      const zz = z + (r() - 0.5) * 30;
      for (let s = 0; s < 6; s++) {
        const nx = x + (r() - 0.5) * 3, ny = y + (r() - 0.5) * 3;
        pts.push(x, y, zz, nx, ny, zz);
        x = nx; y = ny;
      }
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.Float32BufferAttribute(pts, 3));
    return g;
  }, [z]);
  return (
    <lineSegments geometry={geo}>
      <lineBasicMaterial color={MAGENTA} transparent opacity={0.5} blending={THREE.AdditiveBlending} />
    </lineSegments>
  );
}

/* ---------------- Fragmented planet ---------------- */
function FracturedPlanet({ position }: { position: [number, number, number] }) {
  const g = useRef<THREE.Group>(null);
  const shards = useMemo(() => {
    const r = rng(5);
    return Array.from({ length: 22 }, () => {
      const dir = new THREE.Vector3(r() - 0.5, r() - 0.5, r() - 0.5).normalize();
      return { dir, s: 0.6 + r() * 1.2, rot: [r() * 3, r() * 3, r() * 3] as [number, number, number] };
    });
  }, []);
  useFrame(({ clock }) => {
    if (!g.current) return;
    g.current.rotation.y = clock.elapsedTime * 0.05;
    const spread = 3.2 + Math.sin(clock.elapsedTime * 0.3) * 0.3 + voidState.smooth * 3;
    g.current.children.forEach((c, i) => {
      if (i === 0) return;
      c.position.copy(shards[i - 1]!.dir).multiplyScalar(spread);
    });
  });
  return (
    <group ref={g} position={position}>
      <mesh>
        <icosahedronGeometry args={[2.2, 1]} />
        <meshStandardMaterial color="#2a1450" emissive={VIOLET} emissiveIntensity={0.5} flatShading roughness={0.6} />
      </mesh>
      {shards.map((s, i) => (
        <mesh key={i} rotation={s.rot} scale={s.s}>
          <tetrahedronGeometry args={[0.8, 0]} />
          <meshStandardMaterial color="#1a1030" flatShading metalness={0.6} roughness={0.3} />
        </mesh>
      ))}
    </group>
  );
}

/* ---------------- Cosmic anomaly (chapter 03) ---------------- */
function Anomaly({ z, debris }: { z: number; debris: number }) {
  const g = useRef<THREE.Group>(null);
  const ref = useRef<THREE.InstancedMesh>(null);
  const data = useMemo(() => {
    const r = rng(77);
    return Array.from({ length: debris }, () => ({ rad: 16 + r() * 22, a: r() * Math.PI * 2, y: (r() - 0.5) * 3, s: 0.1 + r() * 0.7, sp: 0.02 + r() * 0.06 }));
  }, [debris]);
  const dummy = useMemo(() => new THREE.Object3D(), []);
  useFrame(({ clock }, d) => {
    if (g.current) g.current.rotation.y += d * 0.03;
    const m = ref.current;
    if (!m) return;
    const t = clock.elapsedTime;
    data.forEach((o, i) => {
      const a = o.a + t * o.sp;
      dummy.position.set(Math.cos(a) * o.rad, o.y + Math.sin(a * 3) * 0.3, Math.sin(a) * o.rad);
      dummy.rotation.set(t * o.sp * 5, a, 0);
      dummy.scale.setScalar(o.s);
      dummy.updateMatrix();
      m.setMatrixAt(i, dummy.matrix);
    });
    m.instanceMatrix.needsUpdate = true;
  });
  return (
    <group position={[0, -2, z]} rotation={[0.35, 0, -0.15]}>
      <group ref={g}>
        <mesh>
          <sphereGeometry args={[9, 64, 64]} />
          <meshStandardMaterial color="#05030a" roughness={1} />
        </mesh>
        <mesh rotation={[Math.PI / 2, 0, 0]}>
          <ringGeometry args={[11, 15, 160]} />
          <meshBasicMaterial color={BLUE} transparent opacity={0.35} side={THREE.DoubleSide} blending={THREE.AdditiveBlending} depthWrite={false} />
        </mesh>
        <mesh rotation={[Math.PI / 2, 0, 0]}>
          <torusGeometry args={[15.5, 0.03, 6, 260]} />
          <meshBasicMaterial color={MAGENTA} />
        </mesh>
        <instancedMesh ref={ref} args={[undefined, undefined, debris]}>
          <dodecahedronGeometry args={[1, 0]} />
          <meshStandardMaterial color="#231a35" flatShading metalness={0.5} roughness={0.5} />
        </instancedMesh>
      </group>
      <pointLight color={VIOLET} intensity={400} distance={60} position={[0, 12, 10]} />
    </group>
  );
}

/* ---------------- Dissolve field (chapter 04) ---------------- */
function Dissolve({ z, count }: { z: number; count: number }) {
  const mat = useRef<THREE.PointsMaterial>(null);
  const pts = useRef<THREE.Points>(null);
  const base = useMemo(() => {
    const r = rng(13);
    const a = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      // points on a torus knot-ish folded surface
      const u = r() * Math.PI * 2, v = r() * Math.PI * 2;
      const R = 6 + 2 * Math.cos(3 * u);
      a.set([R * Math.cos(2 * u) + Math.cos(v), R * Math.sin(2 * u) + Math.sin(v), z + 2 * Math.sin(3 * u) + Math.sin(v) * 2], i * 3);
    }
    return a;
  }, [count, z]);
  const geo = useMemo(() => {
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.BufferAttribute(base.slice(), 3));
    return g;
  }, [base]);
  useFrame(({ clock }) => {
    const p = voidState.smooth;
    const k = THREE.MathUtils.smoothstep(p, 0.78, 1) * 30; // dissolve outward
    const arr = geo.attributes['position']!.array as Float32Array;
    for (let i = 0; i < count; i++) {
      const x = base[i * 3]!, y = base[i * 3 + 1]!, zz = base[i * 3 + 2]! - z;
      const f = 1 + k * 0.06 * ((i % 7) / 7 + 0.3);
      arr[i * 3] = x * f;
      arr[i * 3 + 1] = y * f;
      arr[i * 3 + 2] = zz * f + z;
    }
    geo.attributes['position']!.needsUpdate = true;
    if (pts.current) pts.current.rotation.z = clock.elapsedTime * 0.05;
    if (mat.current) mat.current.opacity = 0.9 * (1 - THREE.MathUtils.smoothstep(p, 0.92, 1));
  });
  return (
    <points ref={pts} geometry={geo} position={[0, 0, 0]}>
      <pointsMaterial ref={mat} size={0.08} color={WHITE} transparent depthWrite={false} blending={THREE.AdditiveBlending} />
    </points>
  );
}

/* ---------------- Astronaut silhouette ---------------- */
function Astronaut() {
  const g = useRef<THREE.Group>(null);
  useFrame(({ clock }) => {
    if (!g.current) return;
    const t = clock.elapsedTime;
    g.current.position.set(5.2 + Math.sin(t * 0.3) * 0.2, 1.6 + Math.sin(t * 0.5) * 0.15, 3);
    g.current.rotation.set(0.3 + Math.sin(t * 0.2) * 0.2, t * 0.08, 0.6);
  });
  const m = <meshStandardMaterial color="#d8d4e6" roughness={0.5} metalness={0.1} />;
  return (
    <group ref={g} scale={0.09}>
      <mesh position={[0, 1.6, 0]}>{m}<sphereGeometry args={[0.55, 16, 16]} /></mesh>
      <mesh position={[0, 0.5, 0]}>{m}<capsuleGeometry args={[0.55, 0.9, 4, 10]} /></mesh>
      <mesh position={[0, 0.5, -0.55]}>{m}<boxGeometry args={[0.8, 1, 0.4]} /></mesh>
      <mesh position={[-0.8, 0.7, 0]} rotation={[0, 0, 0.9]}>{m}<capsuleGeometry args={[0.18, 0.8, 4, 8]} /></mesh>
      <mesh position={[0.8, 0.9, 0]} rotation={[0, 0, -1.6]}>{m}<capsuleGeometry args={[0.18, 0.8, 4, 8]} /></mesh>
      <mesh position={[-0.3, -0.7, 0]} rotation={[0.3, 0, 0.2]}>{m}<capsuleGeometry args={[0.22, 0.9, 4, 8]} /></mesh>
      <mesh position={[0.35, -0.6, 0.2]} rotation={[-0.5, 0, -0.1]}>{m}<capsuleGeometry args={[0.22, 0.9, 4, 8]} /></mesh>
      <mesh position={[0, 1.6, 0.42]}><sphereGeometry args={[0.3, 12, 12]} /><meshStandardMaterial color="#120a24" metalness={1} roughness={0.1} emissive={BLUE} emissiveIntensity={0.3} /></mesh>
    </group>
  );
}

/* ---------------- Camera rig ---------------- */
function CameraRig() {
  const { camera, scene } = useThree();
  const look = useMemo(() => new THREE.Vector3(), []);
  const bg = useMemo(() => new THREE.Color(), []);
  const a = useMemo(() => new THREE.Color("#030207"), []);
  const b = useMemo(() => new THREE.Color("#10051F"), []);
  useFrame((_, raw) => {
    const d = Math.min(raw, 0.05);
    voidState.smooth = THREE.MathUtils.damp(voidState.smooth, voidState.scroll, 3, d);
    voidState.enter = THREE.MathUtils.damp(voidState.enter, 0, 0.8, d);
    const p = voidState.smooth;
    const z = cameraZAt(p) - voidState.enter * 6;
    const mx = voidState.mouseX, my = voidState.mouseY;
    camera.position.x = THREE.MathUtils.damp(camera.position.x, mx * 2.2 + Math.sin(p * 9) * 3, 2.5, d);
    camera.position.y = THREE.MathUtils.damp(camera.position.y, my * 1.4 + 0.6, 2.5, d);
    camera.position.z = THREE.MathUtils.damp(camera.position.z, z, 4, d);
    look.set(mx * 0.6, my * 0.3, camera.position.z - 12);
    camera.lookAt(look);
    camera.rotation.z = Math.sin(p * Math.PI * 4) * 0.08 + mx * -0.03;
    // through the portal we tint toward deep purple, then fade back to black
    const tint = Math.sin(Math.min(p * 1.25, 1) * Math.PI);
    bg.copy(a).lerp(b, tint * 0.9);
    scene.background = bg;
    if (scene.fog) (scene.fog as THREE.FogExp2).color.copy(bg);
  });
  return null;
}

export function VoidScene({ low }: { low: boolean }) {
  return (
    <>
      <fogExp2 attach="fog" args={["#030207", 0.018]} />
      <ambientLight intensity={0.15} />
      <directionalLight position={[-8, 6, 6]} intensity={1.2} color={BLUE} />
      <pointLight position={[0, 0, 1]} intensity={60} distance={25} color={VIOLET} />
      <pointLight position={[0, -40, -46]} intensity={300} distance={60} color={MAGENTA} />
      <CameraRig />
      <Stars count={low ? 2500 : 7000} />
      {/* Chapter 00/01 — portal */}
      <group rotation={[0.08, 0, 0.12]}>
        <PortalCore />
        <Rings />
        <Inflow count={low ? 2500 : 9000} />
      </group>
      <Astronaut />
      <Monoliths count={low ? 8 : 14} z={0} spread={34} seed={3} />
      {/* Chapter 02 — fractured reality */}
      <Monoliths count={low ? 16 : 36} z={-52} spread={40} seed={11} glass />
      <Cracks z={-52} />
      <FracturedPlanet position={[7, 2, -60]} />
      {/* Chapter 03 — cosmic abyss */}
      <Anomaly z={-135} debris={low ? 60 : 160} />
      {/* Chapter 04 — beyond */}
      <Dissolve z={-190} count={low ? 3000 : 8000} />
    </>
  );
}
