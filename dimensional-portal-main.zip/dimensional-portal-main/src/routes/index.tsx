import { createFileRoute } from "@tanstack/react-router";
import { Experience } from "@/components/void/Experience";

export const Route = createFileRoute("/")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "VOID — Into the Unknown" },
      { name: "description", content: "An interactive journey through a dimensional portal, fractured realities and the cosmic abyss." },
      { property: "og:title", content: "VOID — Into the Unknown" },
      { property: "og:description", content: "Somewhere beyond the edge of reality, another universe is waiting." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Experience,
});
